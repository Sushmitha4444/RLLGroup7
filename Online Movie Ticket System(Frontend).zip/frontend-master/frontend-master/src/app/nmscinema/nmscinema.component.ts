import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nmscinema',
  templateUrl: './nmscinema.component.html',
  styleUrls: ['./nmscinema.component.css'],
})
export class NmscinemaComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
